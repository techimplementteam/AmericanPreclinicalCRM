<?php 
  $manifest =array(
        'key' => 20160614,
    	'acceptable_sugar_flavors' =>
        array(
            'CE',
            'PRO',
            'CORP',
            'ENT',
            'ULT'
        ),
        'acceptable_sugar_versions' => array(
            'regex_matches' => array(
                '7\\.(.*?)\\.(.*?)\\.(.*?)'
            ),
        ),
        'author' => 'TechImplement Pvt Ltd.',
        'description' => 'Sales Activities Module, automatic naming function from SA16-XXXX to APS16-XXXX.',
        'icon' => '',
        'is_uninstallable' => true,
        'name' => 'Sales Activities Module LogicHook Package',
        'published_date' => '2016-06-14',
        'type' => 'module',
        'version' => '1.0.0',
    );
 $manifest['built_in_version'] = '7.2.0';
 $installdefs = array (
   'copy' => array (
   		/*
		+--------------------------------------
		| In our Sales Activities Module, we would like to updated the automatic naming function from SA16-XXXX to “APS16-XXXX”.
		|
		+--------------------------------------
		*/
		array ( 
			  'from' => '<basepath>/files/customLogicHook.php',
			  'to' => 'custom/modules/M01_Sales/customLogicHook.php',
		)
 		
 	),
 );
 
?>