<?php

class customLogicHook {
    function generateSystemId($bean, $event, $arguments)
    {   global $db;
	    $ID=$bean->id;
		if($bean->fetched_row['id'] == "")
		{
			$workProdCodesID=$bean->m03_work_product_code_id1_c;
			$query="SELECT * FROM m03_work_product_code WHERE id = '$workProdCodesID' AND deleted = 0";
			$obj=$db->query($query);
			$res=$db->fetchByAssoc($obj);
			$nameProd = $res['name'];
			//$bean->name=$nameProd;
			$account_id_c = $bean->account_id_c;
			$query="SELECT client_code_c FROM accounts_cstm WHERE id_c = '$account_id_c' ";
			$obj=$db->query($query);
			$res=$db->fetchByAssoc($obj);
			$clientCode = $res['client_code_c'];
			$sequentialNo = '';
			$new_workPordID = '';
			$query1 = "SELECT
						  name
					  FROM
						  m03_work_product
					  INNER JOIN m03_work_product_cstm ON m03_work_product.id = m03_work_product_cstm.id_c
					  WHERE
						  m03_work_product_cstm.account_id_c = '".$account_id_c."'
					  AND m03_work_product.name LIKE '%-%'
					  ORDER BY
						  m03_work_product.name DESC
					  LIMIT 0,1";
			$_seqNo = $db->query($query1);
			$resultSeqNo	=$db->fetchByAssoc($_seqNo);
			$sequentialNo = $resultSeqNo['name'];
			$GLOBALS['log']->fatal("sequentialNo:".$sequentialNo);
			if(!empty($sequentialNo)){
				$number = explode('-',  $sequentialNo);
				$number = filter_var($sequentialNo, FILTER_SANITIZE_NUMBER_INT);
				$GLOBALS['log']->fatal("number:".$number);
				$number	= $number + 1; 
			}else{
				$number = 001;
			}
			$number= sprintf('%03d', $number);
			if(!empty($clientCode)){
				$new_workPordID = $clientCode.$number.'-'.$nameProd;
			}else{
				$new_workPordID = $number.'-'.$nameProd;
			}
			$bean->name=$new_workPordID;
			$query="UPDATE m03_work_product SET name = '".$new_workPordID."' WHERE id = '$ID' ";
			$obj=$db->query($query);
		}
		#$GLOBALS['log']->fatal("number:".$number);
		#$GLOBALS['log']->fatal("nameProd:".$nameProd);
		#$GLOBALS['log']->fatal("clientCode:".$clientCode); 
    }
 	   
	 
    
        
        
}
