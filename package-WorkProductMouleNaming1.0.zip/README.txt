20-06-2016 (v1.0)
-----------------
"Work Product Coding:
Combine Client Code with a sequential number from work product ID and amend with Work product code. 
Should be editable
I’ve made a quick video with the client: https://vimeo.com/169237054/63e3831b24 "
