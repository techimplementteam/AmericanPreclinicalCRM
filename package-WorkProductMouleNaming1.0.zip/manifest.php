<?php 
  $manifest =array(
        'key' => 20160620,
    	'acceptable_sugar_flavors' =>
        array(
            'CE',
            'PRO',
            'CORP',
            'ENT',
            'ULT'
        ),
        'acceptable_sugar_versions' => array(
            'regex_matches' => array(
                '7\\.(.*?)\\.(.*?)\\.(.*?)'
            ),
        ),
        'author' => 'TechImplement Pvt Ltd.',
        'description' => 'Combine Client Code with a sequential number from work product ID and amend with Work product code.',
        'icon' => '',
        'is_uninstallable' => true,
        'name' => 'Work Product Module Naming',
        'published_date' => '2016-06-20',
        'type' => 'module',
        'version' => '1.0.0',
    );
 $installdefs = array (
   'copy' => array (
   		/*
		+--------------------------------------
		| Combine Client Code with a sequential number from work product ID and amend with Work product code.
		|
		+--------------------------------------
		*/
		array ( 
			  'from' => '<basepath>/files/customLogicHook.php',
			  'to' => 'custom/modules/M03_Work_Product/customLogicHook.php',
		),
		array ( 
			  'from' => '<basepath>/files/logic_hooks.php',
			  'to' => 'custom/modules/M03_Work_Product/logic_hooks.php',
		)
 		
 	),
 );
 
?>