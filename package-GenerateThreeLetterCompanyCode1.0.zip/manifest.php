<?php 
  $manifest =array(
        'key' => 20160616,
    	'acceptable_sugar_flavors' =>
        array(
            'CE',
            'PRO',
            'CORP',
            'ENT',
            'ULT'
        ),
        'acceptable_sugar_versions' => array(
            'regex_matches' => array(
                '7\\.(.*?)\\.(.*?)\\.(.*?)'
            ),
        ),
        'author' => 'TechImplement Pvt Ltd.',
        'description' => 'Automatically generate the three letter Company Code. XXX',
        'icon' => '',
        'is_uninstallable' => true,
        'name' => 'Companies Module LogicHook Package for Company Code',
        'published_date' => '2016-06-16',
        'type' => 'module',
        'version' => '1.0.0',
    );
 $installdefs = array (
   'copy' => array (
   		/*
		+--------------------------------------
		| Automatically generate the three letter Company Code. XXX
		| The code will need to query existing codes and assign an unique code to newly entered companies.
		+--------------------------------------
		*/
		array ( 
			  'from' => '<basepath>/files/logic_hooks.php',
			  'to' => 'custom/modules/Accounts/logic_hooks.php',
		),
		array ( 
			  'from' => '<basepath>/files/accountsLogicHook.php',
			  'to' => 'custom/modules/Accounts/accountsLogicHook.php',
		)
 		
 	),
 );
 
?>