16-06-2016 (v1.0)
-----------------
- Logic Hook
	- Automatically generate the three letter Company Code. XXX
	- The code will need to query existing codes and assign an unique code to newly entered/created companies.