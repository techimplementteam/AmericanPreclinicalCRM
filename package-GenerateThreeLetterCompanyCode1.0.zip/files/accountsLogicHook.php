<?php
/*
	+--------------------------------------
	| Automatically generate the three letter Company Code. XXX
	| The code will need to query existing codes and assign an unique code to newly entered companies.
	| Author: Shahbaz Yousaf
	| Company: TechImplement Pvt Ltd. 
	+--------------------------------------
*/

class accountsLogicHook {
    function generateClicentId($bean, $event, $arguments){
		
		global $db; 
		
		#$GLOBALS['log']->fatal("---------------- generateClicentId ---------------- ");
		$randomString = $this->genrate_code();
		// IF THIS IS NEW RECORD 
		if($bean->fetched_row['id'] == "") {
		
			$bean->client_code_c = $randomString;
			#$GLOBALS['log']->fatal("client_code_c:".$bean->client_code_c);
		}
		else{
			 if ($bean->client_code_c == "" )
			{
			
			   $bean->client_code_c = "" ; //$randomString; 
			

			}else if($bean->client_code_c != "" ){
				
				if($this->check_duplicate($bean->client_code_c , $bean->id )){
					
					$bean->client_code_c = $bean->fetched_row['client_code_c'];//$this->genrate_code();
					
				}else{
					$bean->client_code_c = strtoupper($bean->client_code_c);
				}
			}
		#$GLOBALS['log']->fatal("client_code_c|ELSE:".$bean->client_code_c);
		} 
	}
	/*
	+------------------------
	| Fucntion to Generate UNIQUE THREE Letter Code for company.
	+------------------------
	*/
	function genrate_code(){
		$characters = 'ABCDEFIJKLMNOPGHMNOPQIJKLMNOPRSTUVWIJKLMNOPQIJKLMNOPRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < 3; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		
		if($this->check_duplicate($randomString)){
			 $this->genrate_code();
			}
		else{
			return $randomString;
		}
		
	}
	/*
	+------------------------
	| Fucntion to Check Duplicate THREE Letter Code for company.
	+------------------------
	*/
	function check_duplicate($code , $record_id = ""){
		global $db; 
		$whereClause = "";
		if($record_id != ""){
			$whereClause = " AND id_c != '".$record_id."' ";
		}
		$query = "SELECT id_c from accounts_cstm WHERE client_code_c = '$code'".$whereClause;
		$result = $db->query($query);        
		$row = $db->fetchByAssoc($result);
		if($row['id_c']){
			return 1;
		}else{
			return 0;
		}   
	}

}
